export enum PaymentType {
  Done = 1,
}
