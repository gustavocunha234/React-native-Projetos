export class ReturnGroupOrder {
  order_id: number;
  total: string;
}
