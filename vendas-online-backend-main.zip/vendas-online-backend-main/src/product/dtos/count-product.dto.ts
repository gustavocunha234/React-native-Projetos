export interface CountProduct {
  category_id: number;
  total: number;
}
