export enum CdServiceEnum {
  SEDEX = '04014',
  SEDEX_10 = '40215',
  PAC = '04510',
}
