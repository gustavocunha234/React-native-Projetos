export enum CdFormatEnum {
  BOX = 1,
}
