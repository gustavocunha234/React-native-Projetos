import { DeleteResult } from 'typeorm';

export const returnDeleteMock: DeleteResult = {
  raw: [],
  affected: 1,
};
