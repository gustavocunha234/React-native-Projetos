import { CategoryEntity } from '../entities/category.entity';

export const categoryMock: CategoryEntity = {
  createdAt: new Date(),
  id: 654743,
  name: 'categoryMock',
  updatedAt: new Date(),
};
