import { UpdateCategory } from '../dtos/update-category.dto';

export const updateCategoryMock: UpdateCategory = {
  name: 'updateCategoryMock',
};
