import { CreateCategory } from '../dtos/create-category.dto';

export const createCategoryMock: CreateCategory = {
  name: 'createCategoryMock',
};
