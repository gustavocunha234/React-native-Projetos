export enum UserType {
  User = 1,
  Root = 2,
  Admin = 3,
}
