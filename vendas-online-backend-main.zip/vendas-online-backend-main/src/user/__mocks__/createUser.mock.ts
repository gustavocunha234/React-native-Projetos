import { CreateUserDto } from '../dtos/createUser.dto';

export const createUserMock: CreateUserDto = {
  cpf: '3214215151',
  email: 'emailMockTest@email.com',
  name: 'qudlsjakf',
  password: 'password',
  phone: '325632634',
};
